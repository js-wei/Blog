<a href="http://gruntjs.com" target="_blank"><img src="https://cdn.gruntjs.com/builtwith.png" alt="Built with Grunt"></a> 
# Picker 

A jQuery plugin for replacing default checkboxes and radios. Part of the formstone library. 

- [Demo](http://formstone.it/components/Picker/demo/index.html) 
- [Documentation](http://formstone.it/picker/) 

#### Bower Support 
`bower install Picker`