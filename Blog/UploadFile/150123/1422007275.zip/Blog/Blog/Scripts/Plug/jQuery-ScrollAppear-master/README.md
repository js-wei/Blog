jQuery-ScrollAppear
===================

jQuery ScrollAppear is a powerful and agile content appear on scroll (or on other event triggers) plugin for jQuery.

View the plugin on the <a href="http://plugins.jquery.com/scrollAppear/">jQuery Plugin Registry</a>.

View full documentation at <a href="https://www.domsammut.com/projects/jquery-scrollappear?utm_source=GitHub&utm_medium=readme.md&utm_campaign=jQueryScrollAppear">domsammut.com/projects/jquery-scrollappear</a>.

View a live demo of the plugin at <a href="https://www.domsammut.com/projects/jquery-scrollappear/demo?utm_source=GitHub&utm_medium=readme.md&utm_campaign=jQueryScrollAppear">domsammut.com/projects/jquery-scrollappear/demo</a>
