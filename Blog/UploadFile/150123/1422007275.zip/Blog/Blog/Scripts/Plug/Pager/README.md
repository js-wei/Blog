<a href="http://gruntjs.com" target="_blank"><img src="https://cdn.gruntjs.com/builtwith.png" alt="Built with Grunt"></a> 
# Pager 

A jQuery plugin for simple pagination. Part of the formstone library. 

- [Demo](http://formstone.it/components/Pager/demo/index.html) 
- [Documentation](http://formstone.it/pager/) 

#### Bower Support 
`bower install Pager`