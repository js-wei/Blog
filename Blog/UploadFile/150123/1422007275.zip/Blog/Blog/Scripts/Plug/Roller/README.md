<a href="http://gruntjs.com" target="_blank"><img src="https://cdn.gruntjs.com/builtwith.png" alt="Built with Grunt"></a> 
# Roller 

A jQuery plugin for simple content carousels. Part of the Formstone Library. 

- [Demo](http://formstone.it/components/Roller/demo/index.html) 
- [Documentation](http://formstone.it/roller/) 

#### Bower Support 
`bower install Roller` 