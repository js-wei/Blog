using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
namespace Blog.Model
{
	public class Column 
	{
 		public  int  id{ get; set; }
		public  int  fid{ get ;set;}
		public  string  name{ get ;set;}
		public  string  title{ get ;set;}
		public  string  keyword{ get ;set;}
		public  string  description{ get ;set;}
		public  string  banner{ get ;set;}
		public  string  image{ get ;set;}
		public  string  ico{ get ;set;}
		public  string  type{ get ;set;}
		public  string  uri{ get ;set;}
		public  int  position{ get ;set;}
		public  int  sort{ get ;set;}
		public  int  is_show{ get ;set;}
		public  int  effective{ get ;set;}
		public  int  status{ get ;set;}
		public  int  create_time{ get ;set;}
 
	}
}