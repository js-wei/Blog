using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
namespace Blog.Model
{
	public class Person 
	{
 		public  int  id{ get; set; }
		public  string  name{ get ;set;}
		public  int  age{ get ;set;}
		public  string  sex{ get ;set;}
		public  string  address{ get ;set;}
 
	}
}