using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
namespace Blog.Model
{
	public class Membersafe 
	{
 		public  int  id{ get; set; }
		public  int  mid{ get ;set;}
		public  int  aid{ get ;set;}
		public  string  answer{ get ;set;}
		public  int  askType{ get ;set;}
		public  int  safeType{ get ;set;}
 
	}
}